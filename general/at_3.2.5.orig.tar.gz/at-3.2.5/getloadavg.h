int getloadavg(double *result, int n);
